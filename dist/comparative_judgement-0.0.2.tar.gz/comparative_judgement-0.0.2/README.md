# Comparative Judgement

A package for comparative judgement (CJ).
