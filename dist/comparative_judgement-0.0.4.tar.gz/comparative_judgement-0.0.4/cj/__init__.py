# https://www.youtube.com/watch?v=OI6M9BRwfJM

# from .cj_ranking import *
from .models import *