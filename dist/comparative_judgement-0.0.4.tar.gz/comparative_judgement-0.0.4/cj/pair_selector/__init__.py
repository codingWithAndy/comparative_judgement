from .entropy import EntropyPairSelector
from .random  import RandomPairSelector