
# class BayesianCJ:
#     def check(self):
#         print("BayesianCJ")
    

# class BTMCJ:
#     print("BTMCJ")