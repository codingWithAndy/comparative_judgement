class RandomPairSelector:
    pass